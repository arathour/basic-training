var fruits = ["Banana", "Orange", "Apple"];
var str = "Kiwi";
var myPush = function(fruits, str) {
        fruits[fruits.length] = str;
    }
    // myPush(fruits, str)
    // console.log(fruits);

var myPop = function() {
        fruits.length = fruits.length - 1;
    }
    // myPop(fruits)
    // console.log(fruits);

var myShift = function() {
        for (let i = 0; i < fruits.length; i++) {
            fruits[i] = fruits[i + 1];
        }
        myPop(fruits);
    }
    // myShift();
    // console.log(fruits);

var myUnShift = function(str) {
        for (let i = fruits.length; i > 0; i--) {
            fruits[i] = fruits[i - 1];
        }
        fruits[0] = str
    }
    // myUnShift(str);
    // console.log(fruits);

var myLength = function() {
        var count = 0;
        fruits.forEach(
            num => { count++; }
        )
        return count;
    }
    //console.log(myLength());

var myIndexOf = function(str) {
        for (var val = 0; val < fruits.length; val++) {
            if (fruits[val] === str) {
                return val;
            }
        }
        return -1;
    }
    //console.log(myIndexOf(str));

Array.prototype.myEach = function(callback) {
    for (var i = 0; i < this.length; i++)
        callback(this[i], i, this);
};

fruits.myEach(function(word) {
    console.log(word);
});