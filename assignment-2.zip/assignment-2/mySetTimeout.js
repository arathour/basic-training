var newSetTimeout = function(time, fun) {
    var currentTime = new Date();
    var futureTime = new Date();
    futureTime.setMilliseconds(currentTime.getMilliseconds() + time);
    while (currentTime.getTime() != futureTime.getTime()) {
        currentTime = new Date();
    }
    return fun();
};

newSetTimeout(2000, () => {
    console.log("Executed");
});