/^[^.]\w+[!#$%&'*+-/=?^_`{|}~]*(?<!\.)$/

/
^
\w + [. - ] ? \w + @\ w + [.] { 1 }\
w { 2, 4 }(.\w + ) ? $ /

    /^4[0-9]{12}(?:[0-9]{3})?/ // VISA card Visa cards – Begin with a 4 and have 13 or 16 digits